//與all相同
$(document).ready(function(){
    
    $("#buynow-btn").click(function(e){
        $.ajax({
            type:"GET",
            url:"/item?id=" + $("#id").val(),//跳轉到item的id頁面
            success: function(response){
                
                
            }
        });
    });


    $(".buynow-btn").on("click", function () {
        //$.ajax({
            //type:"GET",
            //url:"/item?id=" + $(this).prop("value"),//顯示不同的id(流水號 )
            //success: function(response){

                location.href="/item?id="+$(this).prop("value")//跳轉頁面
                
            //}
        //});
    });
});