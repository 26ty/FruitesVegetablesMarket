$(document).ready(function(){
    /*$("buynow-btn#").click(function(e){
        $.ajax({
            type:"POST",
            url:"/item?id=" + $("#id").val(),
            success: function(response){  
            }
        });
    });*/
    //id = request.args.get('id')
    // var strUrl=location.search;
    // var getPara,ParaVal;
    // var aryara=[]

    // if(strUrl.id != -1)
    //宣告變數
    var num_add = document.getElementById("num-add");
    var num_min = document.getElementById("num-min");
    var input_num = document.getElementById("input-num");

    $("#num-add").click(function (e) { 

        input_num.value = parseInt(input_num.value) + 1;

        //e.preventDefault();
        
    });
    $("#num-min").click(function (e) {

        if(input_num.value<=0){

            input_num.value = 0;

        }else{
            
            input_num.value = parseInt(input_num.value) - 1;

        }
        
        //e.preventDefault();
        
    });
    //按編輯紐的時候抓取/modifyProduct?id=XXXXXX 然後跳轉到modi頁面
    $("#item-modi").click(function (e) { 
        $.ajax({
            type:"GET",
            url:"/modifyProduct?id=" + $("#id").val(),
            success: function(response){
                
                
            }
        });
        
    });

    $("#item-modi").on("click",function(){
        location.href="/modifyProduct?id="+$(this).prop("value")//跳轉頁面
    });
});