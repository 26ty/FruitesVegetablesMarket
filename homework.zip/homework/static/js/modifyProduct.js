$(document).on('click', '#output-btn', function (e) {
    if($("#productName").val() == "" || $("#productPrice") == "" || $("#introduction") == ""){
        $.confirm({
            title:'錯誤!',
            animation:'zoom',
            closeAnimation:'scale',
            content:'請完整填寫!',
            buttons:{
                確認:{
                    btnClass:'btn-success',
                    action:function(){
                        //location.href="/modifyProduct?id=" + $("#output-btn").val()
                        // location.reload()
                    }
                }
            }
        });
        $("#productName").val("")
        $("#productPrice").val("")
        $("#introduction").val("")
    }else{
        $.ajax({
            type: "POST",
            //類似新增一樣 url要抓每個input的值
            url: "/modifyProduct?id=" + $("#output-btn").val() +"&productName=" +  $("#productName").val() + "&introduction=" + $("#introduction").val() + "&productPrice=" + $("#productPrice").val(),
            // data: "data",
            // dataType: "dataType",
            success: function (response) {
                $.confirm({
                    title:'成功!',
                    animation:'zoom',
                    closeAnimation:'scale',
                    content:'修改成功!',
                    buttons:{
                        確認:{
                            btnClass:'btn-success',
                            action:function(){
                                location.href="/item?id=" + $("#output-btn").val()
                                // location.reload()
                            }
                        }
                    }
                });
            }
        });
    }
    
});
//刪除按鈕
$(document).ready(function () {
    $("#item-del").click(function (e) { 
        $.ajax({
            type: "GET",
            url: "/modifyProduct?id=" + $("#item-del").val(),
            success: function (response) {
                $.confirm({
                    title:'成功!',
                    animation:'zoom',
                    closeAnimation:'scale',
                    content:'已刪除!',
                    buttons:{
                        確認:{
                            btnClass:'btn-success',
                            action:function(){
                                location.href = "/all"
                            }
                        }
                    } 
                });
            }
        });
        
    });
});